from django.apps import AppConfig


class ClothesShopConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'clothes_shop'
